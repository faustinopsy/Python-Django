from setuptools import setup

setup(
    name = 'modulo_exemplo',
    version = '1.0',
    description = 'Calculo de areas simples',
    author = 'Testes de Codigo',
    author_email = 'teste@teste.com',
    url = 'altabooks.com.br',
    py_modules = ['modulo_exemplo'],
)
